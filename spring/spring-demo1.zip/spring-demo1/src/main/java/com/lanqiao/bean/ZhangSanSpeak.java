package com.lanqiao.bean;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class ZhangSanSpeak {
    private String name;
    private String content;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void speak() {
        System.out.println(name + "说：" + content);
    }
}
