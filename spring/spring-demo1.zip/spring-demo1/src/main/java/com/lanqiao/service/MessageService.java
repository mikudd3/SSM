package com.lanqiao.service;

import com.lanqiao.dao.IMessage;
import com.lanqiao.dao.impl.MessageCN;
import com.lanqiao.dao.impl.MessageEN;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
@Component("MessageService")
public class MessageService {

    @Autowired
    private IMessage iMessage;

    public void handleMessage() {
        if (iMessage instanceof MessageCN) {
            ((MessageCN) iMessage).setMsg("李丽");
        } else if (iMessage instanceof MessageEN) {
            ((MessageEN) iMessage).setMsg("Lily");
        }

        iMessage.doMessage();
    }
}
