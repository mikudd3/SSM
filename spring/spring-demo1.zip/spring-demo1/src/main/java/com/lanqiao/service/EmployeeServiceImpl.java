package com.lanqiao.service;

import com.lanqiao.pojo.Employees;

import java.util.ArrayList;
import java.util.List;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class EmployeeServiceImpl implements IEmployeeService {

    private static List<Employees> list = new ArrayList<>();

    @Override
    public boolean addEmployee(Employees employees) {

        list.add(employees);
        System.out.println("进入添加员工业务逻辑方法”");
        return true;
    }

    @Override
    public List<Employees> getAllEmployees() {
        System.out.println("进入获取所有员工业务逻辑方法");

        return list;
    }
}
