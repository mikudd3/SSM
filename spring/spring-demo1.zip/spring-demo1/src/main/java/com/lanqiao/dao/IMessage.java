package com.lanqiao.dao;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public interface IMessage {

    void doMessage();
}
