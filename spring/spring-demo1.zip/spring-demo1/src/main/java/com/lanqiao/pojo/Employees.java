package com.lanqiao.pojo;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class Employees {
    // 员工编号
    private String employeeId;
    // 员工姓名
    private String employeeName;
    // 员工性别
    private String employeeSex;
    // 员工出生日期
    private String employeeBirthday;
    // 员工入职日期
    private String employeeHiredate;
    // 用户编号
    private Integer userId;

    public Employees() {

    }

    public Employees(String employeeId, String employeeName, String employeeSex, String employeeBirthday,
                     String employeeHiredate, Integer userId) {
        super();
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.employeeSex = employeeSex;
        this.employeeBirthday = employeeBirthday;
        this.employeeHiredate = employeeHiredate;
        this.userId = userId;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmployeeSex() {
        return employeeSex;
    }

    public void setEmployeeSex(String employeeSex) {
        this.employeeSex = employeeSex;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getEmployeeBirthday() {
        return employeeBirthday;
    }

    public void setEmployeeBirthday(String employeeBirthday) {
        this.employeeBirthday = employeeBirthday;
    }

    public String getEmployeeHiredate() {
        return employeeHiredate;
    }

    public void setEmployeeHiredate(String employeeHiredate) {
        this.employeeHiredate = employeeHiredate;
    }

    @Override
    public String toString() {
        return "Employees [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeSex=" + employeeSex
                + ", employeeBirthday=" + employeeBirthday + ", employeeHiredate=" + employeeHiredate + ", userId="
                + userId + "]";
    }
}