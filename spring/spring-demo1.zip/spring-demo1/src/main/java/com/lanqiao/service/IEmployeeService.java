package com.lanqiao.service;

import com.lanqiao.pojo.Employees;

import java.util.List;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public interface IEmployeeService {

    boolean addEmployee(Employees employees);


    List<Employees> getAllEmployees();
}
