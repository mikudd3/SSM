package com.lanqiao.dao.impl;

import com.lanqiao.dao.IMessage;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class MessageEN implements IMessage {
    private String msg;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    @Override
    public void doMessage() {
        System.out.println("你好," + msg);
    }
}
