package com.lanqiao.config;

import com.lanqiao.dao.IMessage;
import com.lanqiao.dao.impl.MessageEN;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
@Configuration
public class SpringConfig {

    @Bean
    public IMessage getMessage() {

        return new MessageEN();
    }
}
