package com.mikudd3.config;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;

import javax.sql.DataSource;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
@PropertySource("db.properties")
public class MyBatisConfig {


    /**
     * 创建sqlSessionFactory
     * @param dataSource
     * @return
     */
    @Bean
    public SqlSessionFactoryBean sqlSessionFactory(DataSource dataSource) {
        SqlSessionFactoryBean ssfb = new SqlSessionFactoryBean();
        //mapper路径
        ssfb.setTypeAliasesPackage("com.mikudd3.pojo");
        ssfb.setDataSource(dataSource);
        return ssfb;
    }

    /**
     * 映射扫描配置类
     * @return
     */
    @Bean
    public MapperScannerConfigurer mapperScannerConfigurer(){
        MapperScannerConfigurer msc = new MapperScannerConfigurer();
        msc.setBasePackage("com.mikudd3.dao");
        return msc;
    }
}
