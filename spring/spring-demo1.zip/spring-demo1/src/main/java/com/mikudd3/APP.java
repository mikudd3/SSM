package com.mikudd3;

import com.mikudd3.config.SpringConfig;
import com.mikudd3.pojo.Account;
import com.mikudd3.service.AccountService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.sql.DataSource;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class APP {
    public static void main(String[] args) {
        //引入spring配置文件
//        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        //获取对象
//        DataSource dataSource = (DataSource) context.getBean("dataSource");
//        System.out.println(dataSource);

        //使用spring整合mybatis
        ApplicationContext ctx = new AnnotationConfigApplicationContext(SpringConfig.class);

        AccountService accountService = ctx.getBean(AccountService.class);

        Account ac = accountService.findById(1);
//        System.out.println();

    }
}
