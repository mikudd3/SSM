package com.mikudd3.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;

/**
 * @project: spring配置类
 * @author: mikudd3
 * @version: 1.0
 */

@Configuration
@ComponentScan("com.mikudd3")
@PropertySource("classpath:db.properties")
@Import({MyBatisConfig.class, JdbcConfig.class})
public class SpringConfig {
}
