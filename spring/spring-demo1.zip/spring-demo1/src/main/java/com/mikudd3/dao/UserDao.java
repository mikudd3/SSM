package com.mikudd3.dao;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class UserDao {
}
