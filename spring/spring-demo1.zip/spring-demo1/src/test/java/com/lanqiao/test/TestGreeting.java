package com.lanqiao.test;

import com.lanqiao.dao.impl.MessageEN;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class TestGreeting {

    @Test
    public void testGreeting() {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");

        MessageEN messageEN = ctx.getBean("MessageEN", MessageEN.class);

        messageEN.doMessage();
    }
}
