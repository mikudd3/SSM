package com.example.first.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
@Controller
@RequestMapping("/user")
public class UserController {

    @RequestMapping("/login")
    public String welcomeUserLogin() {
        return "login";
    }
}
