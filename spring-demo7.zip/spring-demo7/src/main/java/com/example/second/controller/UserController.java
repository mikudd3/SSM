package com.example.second.controller;

import com.example.second.db.UserDB;
import com.example.second.pojo.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
@Controller
public class UserController {

    private static int nextId = 4;

    @RequestMapping(value = "/adduser", method = RequestMethod.GET)
    public String showAddUserPage(Model model) {
        model.addAttribute("user", new User());
        return "addUser";
    }

    @RequestMapping(value = "/adduser", method = RequestMethod.POST)
    public String processAddUser(@ModelAttribute User user, Model model) {
        user.setUid(nextId++);
        UserDB.userMap.put(user.getUid(), user);
        List<User> userList = null;
        Map<Integer, User> userMap = UserDB.userMap;
        Set<Integer> keys = userMap.keySet();
        for (Integer key : keys) {
            userList.add(userMap.get(key));
        }
        model.addAttribute("userList", userList);
        return "userlist";
    }

}
