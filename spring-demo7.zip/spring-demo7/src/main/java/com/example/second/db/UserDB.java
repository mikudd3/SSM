package com.example.second.db;

import com.example.second.pojo.User;

import java.util.HashMap;
import java.util.Map;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class UserDB {
    public static Map<Integer, User> userMap = new HashMap<Integer,User>();
    static{
        User u1=new User(1,"yangguo","杨过","123456","13344445555","yangguo@langqiao.org","男","中囯");
        User u2=new User(2,"xiaolongnv","小龙女","888888","13344446666","xiaolongnv@langqiao.org","女","中囯");
        User u3=new User(3,"guojing","郭靖","666666","13344447777","guojing@langqiao.org","男","中囯");
        User u4=new User(4,"huangrong","黄蓉","000000","13344448888","huangrong@langqiao.org","女","中囯");
        User u5=new User(5,"zhangwuji","张无忌","777777","13344449999","zhangwuji@langqiao.org","男","中囯");

        userMap.put(u1.getUid(), u1);
        userMap.put(u2.getUid(), u2);
        userMap.put(u3.getUid(), u3);
        userMap.put(u4.getUid(), u4);
        userMap.put(u5.getUid(), u5);
    }
}