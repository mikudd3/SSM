package com.example.second.controller;

import com.example.second.db.UserDB;
import com.example.second.pojo.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */

@Controller
public class LoginController {

    private static final String USERNAME = "admin";
    private static final String PASSWORD = "123";

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String showLoginPage() {
        return "login";
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String processLogin(@RequestParam String username, @RequestParam String password, Model model) {
        if (USERNAME.equals(username) && PASSWORD.equals(password)) {
            List<User> userList = null;
            Map<Integer, User> userMap = UserDB.userMap;
            Set<Integer> keys = userMap.keySet();
            for (Integer key : keys) {
                userList.add(userMap.get(key));
            }
            model.addAttribute("userList", userList);
            return "userlist";
        } else {
            model.addAttribute("errorMsg", "用户名或密码错误");
            return "login";
        }
    }

}
