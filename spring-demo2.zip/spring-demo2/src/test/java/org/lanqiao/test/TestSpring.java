package org.lanqiao.test;

import org.junit.Test;
import org.lanqiao.pojo.Employees;
import org.lanqiao.service.IEmployeeService;
import org.lanqiao.service.IMessageService;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import static org.junit.Assert.assertTrue;
import java.util.List;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class TestSpring {


    @Test
    public void testBeforeAdvice() {
        ClassPathXmlApplicationContext context =
                new ClassPathXmlApplicationContext("applicationContext.xml");
        IMessageService ms = context.getBean(IMessageService.class);
        System.out.println(ms.getInfo("小桃子", 6));
        context.close();
    }

    @Test
    public void testNameMatchMethodPointcutAdvisor(){
        ClassPathXmlApplicationContext context =
                new ClassPathXmlApplicationContext("applicationContext.xml");
        IMessageService ms = context.getBean(IMessageService.class);
        System.out.println(ms.getInfo2("小桃子", 0));

        ms.addInfo("张三", 170);

        ms.modifyInfo("李四", 20);
        ms.removeInfo("王五", 30);
        context.close();
    }


    @Test
    public void test(){
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        IEmployeeService ies = context.getBean(IEmployeeService.class);
        assertTrue(ies.addEmployee(context.getBean("emp1", Employees.class)));
        assertTrue(ies.addEmployee(context.getBean("emp2", Employees.class)));
        assertTrue(ies.addEmployee(context.getBean("emp3", Employees.class)));
        assertTrue(ies.addEmployee(context.getBean("emp4", Employees.class)));
        assertTrue(ies.addEmployee(context.getBean("emp5", Employees.class)));

        List<Employees> list = ies.getAllEmployees();
        for (Employees employee : list) {
            System.out.println(employee);
        }
        context.close();
    }

}
