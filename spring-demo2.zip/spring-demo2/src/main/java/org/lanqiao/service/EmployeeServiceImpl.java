package org.lanqiao.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.lanqiao.pojo.Employees;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */

@Service
public class EmployeeServiceImpl implements IEmployeeService {

    private Log log = LogFactory.getLog(EmployeeServiceImpl.class);
    private static List<Employees> employees;

    public EmployeeServiceImpl() {
        employees = new ArrayList<>();
    }

    @Override
    public boolean addEmployee(Employees emp) {
        log.info("进入添加员工业务逻辑方法");
        return employees.add(emp);
    }

    @Override
    public List<Employees> getAllEmployees() {
        log.info("进入获取所有员工业务逻辑方法");
        return employees;
    }

}