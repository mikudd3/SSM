package org.lanqiao.service;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */

public interface EmployeeService {

    /**
     *  员工登录
     * @param name 用功姓名
     * @param password 密码
     * @return
     */
    public String login(String name,String password);
}