package org.lanqiao.service;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */

public class MessageServiceImpl implements IMessageService {
    @Override
    public String getInfo(String name, int age) {
        System.out.println("进入getInfo()方法");
        return "姓名:" + name + "   年龄:" + String.valueOf(age);
    }


    @Override
    public String getInfo2(String name, int age) {
        System.out.println("进入getInfo2()方法");
        return "姓名:" + name + "   年龄:" + String.valueOf(age);
    }

    @Override
    public void addInfo(String name, int age) {
        System.out.println("进入addInfo()方法");
        System.out.println("姓名:" + name + "   年龄:" + String.valueOf(age) + "信息已添加");
    }

    @Override
    public void modifyInfo(String name, int age) {
        System.out.println("进入modifyInfo()方法");
        System.out.println("姓名:" + name + "   年龄:" + String.valueOf(age) + "信息已修改");
    }

    @Override
    public void removeInfo(String name, int age) {
        System.out.println("进入removeInfo()方法");
        System.out.println("姓名:" + name + "   年龄:" + String.valueOf(age) + "信息已删除");
    }




}
