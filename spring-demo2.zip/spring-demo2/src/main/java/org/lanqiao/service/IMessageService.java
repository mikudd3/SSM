package org.lanqiao.service;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public interface IMessageService {
    /**
     * 获取基本信息
     *
     * @param name 姓名
     * @param age  年龄
     * @return 基本信息
     */
    public String getInfo(String name, int age);

    public String getInfo2(String name, int age);

    public void addInfo(String name, int age);

    public void modifyInfo(String name, int age);

    public void removeInfo(String name, int age);

    //提供了 5 个业务逻辑方法，这 5 个方法都是连接点 Joinpoint
}