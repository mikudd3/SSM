package org.lanqiao.service;

import org.lanqiao.pojo.Employees;

import java.util.List;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public interface IEmployeeService {

    /**
     * 将 xml 文件中的员工信息添加到 List 集合中
     *
     * @param emp 员工基本信息
     * @return 是否添加成功
     */
    public boolean addEmployee(Employees emp);

    /**
     * 获取所有员工信息
     *
     * @return 员工集合
     */
    public List<Employees> getAllEmployees();
}