package org.lanqiao.advice;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class MessageAroundAdvice {

    private Log log = LogFactory.getLog(MessageBeforeAdvice.class);

    public Object around(ProceedingJoinPoint pjp) throws Throwable {
        log.info("环绕通知操作开始");
        //获取参数
        Object[] args = pjp.getArgs();
        //获取年龄
        //输出年龄信息
        log.info("输入年龄：：" + (int) args[1]);
        if ((int) args[1] <= 0 || (Integer) (int) args[1] > 160) {
            log.error("参数错误：年龄必须在 1-160 之间!");
            args[1] = 1;
        }

        Object ret = pjp.proceed(args);
        log.info("环绕通知操作结束");
        return ret;
    }
}
