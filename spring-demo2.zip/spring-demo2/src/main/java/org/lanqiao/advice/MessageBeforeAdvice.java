package org.lanqiao.advice;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.MethodBeforeAdvice;

import java.lang.reflect.Method;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class MessageBeforeAdvice implements MethodBeforeAdvice {
    // 创建日志对象
    private Log log = LogFactory.getLog(MessageBeforeAdvice.class);

   /* @Override
    public void before(Method arg0, Object[] arg1, Object arg2) throws Throwable {
        //通过日志信息返回各个参数的信息
        log.info("目标对象：" + arg2);
        log.info("访问方法名：" + arg0.getName());
        log.info("姓名：" + arg1[0]);
        log.info("年龄：" + arg1[1]);
    }*/

//    @Override
//    public void before(Method arg0, Object[] arg1, Object arg2) throws Throwable {
//        // 通过日志收集各个参数的信息
//        System.out.println("==========================");
//        log.info("访问的方法名：" + arg0.getName());
//        log.info("员工姓名：" + arg1[0]);
//        log.info("密码：" + arg1[1]);
//        log.info("目标对象：" + arg2);
//        System.out.println("==========================");
//
//    }

    @Override
    public void before(Method arg0, Object[] arg1, Object arg2) throws Throwable {
        // 通过日志收集各个参数的信息
        log.info("输入年龄：：" + arg1[1]);
        if ((Integer) arg1[1] <= 0 || (Integer) arg1[1] > 160) {
            log.error("参数错误：年龄必须在 1-160 之间!");
            arg1[1] = 1;
        }
    }

}