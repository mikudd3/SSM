package org.lanqiao.advice;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class EmployeeAdvice {
    private Log log = LogFactory.getLog(EmployeeAdvice.class);

    // 环绕通知
    @Around("execution(* org.lanqiao.service.IEmployeeService.*(..))")
    public Object around1(ProceedingJoinPoint pjp) throws Throwable {
        System.out.println("========环绕通知开始========");
        String methodName = pjp.getSignature().getName();
        System.out.println("切入点方法：" + methodName);
        Object result = pjp.proceed();
        System.out.println("完成业务逻辑方法调用，方法返回数据：" + result);
        return result;
    }


    @Around("execution(boolean org.lanqiao.service.IEmployeeService.add*(..))")
    public Object around2(ProceedingJoinPoint pjp) throws Throwable {
        System.out.println("========环绕通知开始========");
        Object[] args = pjp.getArgs();
        String sex = (String) args[2];
        log.info("输入的员工性别为：" + sex);
        if (!"男".equals(sex) && !"女".equals(sex)) {
            log.error("参数错误：员工性别必须为男或女！系统默认设置为男：");
            args[2] = "男";
        }
        Object result = pjp.proceed(args);
        if ((Boolean) result) {
            log.info("员工数据更新成功");
        } else {
            log.info("员工数据更新失败");
        }
        System.out.println("========环绕通知结束========");
        return result;
    }
}
