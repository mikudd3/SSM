package org.lanqiao;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class RemindJob {

    public void remind() {
        //任务提示的字符串为 “起床刷牙洗脸啦” 和 “当前系统时间 - 2021-6-23 14:11:23”，当前时间是动态可变的。
        //获取当前时间
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String formattedDate = formatter.format(date);
        System.out.println("起床刷牙洗脸啦");
        System.out.println("当前系统时间 -" + formattedDate);


    }
}
