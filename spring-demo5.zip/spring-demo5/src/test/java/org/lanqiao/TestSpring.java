package org.lanqiao;

import org.junit.Test;
import org.quartz.Scheduler;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class TestSpring {

    @Test
    public void test() throws Exception {
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
        Scheduler scheduler = (Scheduler) context.getBean("schedulerFactory");

        System.out.println("调度任务开始");
        scheduler.start();
        Thread.sleep(30000); // 调度开始至结束间隔时间为 30 秒
        scheduler.shutdown(true);
        System.out.println("调度任务完成");
    }
}
